# BeerPongEWHA
171020 노태경

review3.php -> writereview.php로 연결할 때 
writereview.php 아직 해결 X : F12 적용했을 때 빈 페이지로 나옴. php 코드 뜨지 않음.

PHP Warning:  mysqli_connect(): (HY000/2002): PHP Fatal error:  Uncaught Error: Call to a member function query() on boolean in C:\xampp\htdocs\writereview.php:155                                                                             Stack trace:                                                                                                            #0 {main}                                                                                                                 thrown in C:\xampp\htdocs\writereview.php on line 155                                                                                                                                                                                         Fatal error: Uncaught Error: Call to a member function query() on boolean in C:\xampp\htdocs\writereview.php:155        Stack trace:                                                                                                            #0 {main}                                                                                                                 thrown in C:\xampp\htdocs\writereview.php on line 155   
